# TPO1-Grp24Comision23506
TPO1 Grp24Comision23506

El trabajo debe ser entregado durante la Clase 22, desde el miércoles 18

- 👋 Hi, I’m @Grupo24Comision23506
- 👀 I’m interested in ...
- 🌱 I’m currently learning ...
- 💞️ I’m looking to collaborate on ...
- 📫 How to reach me ...

<!---
Grupo24Comision23506/Grupo24Comision23506 is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->
